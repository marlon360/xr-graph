# XR Browser Extension

The extension injects custom Javascript Code to math websites.
If a function is detected, a button with a link to xr-graph will be added to the website.
